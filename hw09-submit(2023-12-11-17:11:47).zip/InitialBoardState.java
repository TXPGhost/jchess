package org.cis1200.chess;

public enum InitialBoardState {
    StandardChess,
    Empty,
}
