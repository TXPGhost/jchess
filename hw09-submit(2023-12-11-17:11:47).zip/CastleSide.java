package org.cis1200.chess;

public enum CastleSide {
    King,
    Queen,
}
